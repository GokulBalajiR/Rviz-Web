cd
cd Rviz_web_project
cd frames
rosrun image_view extract_images _sec_per_frame:=0.5 image:=/rviz1/camera2/image_compressed _image_transport:=compressed