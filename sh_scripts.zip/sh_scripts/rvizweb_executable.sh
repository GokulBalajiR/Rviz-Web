#!/bin/sh
cd
rm -rf /home/gokulbalaji/Rviz_web_project/frames/* 
cd Rviz_web_project/sh_scripts
gnome-terminal -- ./run1.sh
//gnome-terminal -- ./run2.sh
gnome-terminal -- ./run3.sh
sleep 7
gnome-terminal -- ./run4.sh
