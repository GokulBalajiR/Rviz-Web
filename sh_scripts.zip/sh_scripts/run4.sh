cd 

cd Rviz_web_project
cd fire
python3 image_upload.py