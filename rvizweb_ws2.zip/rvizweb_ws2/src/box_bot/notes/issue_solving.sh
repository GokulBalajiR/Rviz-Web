# Solving issues

# When compiling the : https://github.com/sumitbinnani/ros-realtime-image-stitching
# In file included from /home/user/simulation_ws/src/ros-realtime-image-stitching/src/stitch_images.cpp:2:
# /home/user/simulation_ws/src/ros-realtime-image-stitching/include/image_stitcher.h:11:10: fatal error: opencv2/xfeatures2d.hpp: No such file or directory
#    11 | #include <opencv2/xfeatures2d.hpp>

# >> I have to install OpenCV contrib. In ROSDS, we dont have cude support normally so, we will probably nee dto compile without it
# https://github.com/Extended-Object-Detection-ROS/wiki_english/wiki/opencv_contrib_noetic_install

cd
mkdir Libs
cd Libs 
git clone https://github.com/opencv/opencv.git
git clone https://github.com/opencv/opencv_contrib.git
cd opencv_contrib
git checkout 4.2.0
cd ../opencv
git checkout 4.2.0
NEW_OPENCV_LIB_PATH=/home/user/simulation_ws/Libs/opencv_contrib/modules
#NEW_OPENCV_LIB_PATH=/home/tgrip/TheConstruct/ros_playground/box_bot_ws/Libs/opencv_contrib/modules
echo $NEW_OPENCV_LIB_PATH
mkdir build
cd build
cmake -D CMAKE_BUILD_TYPE=RELEASE -D CMAKE_INSTALL_PREFIX=/usr/local -D INSTALL_C_EXAMPLES=ON -D INSTALL_PYTHON_EXAMPLES=ON -D WITH_TBB=ON -D WITH_V4L=ON -D OPENCV_EXTRA_MODULES_PATH=$NEW_OPENCV_LIB_PATH -D OPENCV_ENABLE_NONFREE=ON -D WITH_CUDA=OFF -D BUILD_EXAMPLES=ON ..
nproc
# Get The number or processes in your system ( in ROSDS there are 36 , tested that it compiles super fast)
make -j4

sudo make install
# It installs among other hings the libraies and samples: /usr/local/share/opencv4/samples/python/
sudo sh -c 'echo "/usr/local/lib" >> /etc/ld.so.conf.d/opencv.conf'
sudo ldconfig

# Remove the buidl and devel of the catkin_ws and catiin_make again

rosrun stitch_images stitch_images  _left:=/cam1_left/image_raw _right:=/cam1_right/image_raw