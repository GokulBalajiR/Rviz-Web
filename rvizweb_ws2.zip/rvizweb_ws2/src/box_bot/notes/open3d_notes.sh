####
# Install
pip install open3d-python



# Most important repos open 3D

https://github.com.cnpmjs.org/intel-isl/Open3D-ML

# Install

pip3 install open3d
# We install Pytorch to avoid messing with tesnorflow other install. Test Tensorflow ( you can use also pytorch)

cd Open3D-ML
# To install a compatible version of TensorFlow
#pip install -r requirements-tensorflow.txt
# To install a compatible version of PyTorch with CUDA
pip3 install -r requirements-torch-cuda.txt

#To test the installation use

# with PyTorch
$ python -c "import open3d.ml.torch as ml3d"
# or with TensorFlow
#$ python -c "import open3d.ml.tf as ml3d"


#### It seems that for catkin make we might ened to install from source
git clone --recursive https://github.com/intel-isl/Open3D
cd Open3D
util/install_deps_ubuntu.sh
# Thsi command failed butwe ocntinue

mkdir build
cd build
cmake -DCMAKE_INSTALL_PREFIX=/usr/local ..

CMake 3.18 or higher is required.  You are running version 3.16.3
