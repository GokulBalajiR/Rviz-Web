#!/usr/bin/env python3

import rospy
from gazebo_msgs.msg import ModelStates
from geometry_msgs.msg import Pose

def position_callback(msg):
    robot_pose = Pose()
    for i in range(len(msg.name)):
        if msg.name[i] == 'robot':
            robot_pose = msg.pose[i]
            break
    position_pub.publish(robot_pose.position)

rospy.init_node('robot_position_publisher')
position_pub = rospy.Publisher('robot_position', Point, queue_size=10)
rospy.Subscriber('/gazebo/model_states', ModelStates, position_callback)
rospy.spin()
