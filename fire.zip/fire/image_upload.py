import pyrebase
import time
filePath= "/home/gokulbalaji/Rviz_web_project/frames/"
config = {
  "apiKey": "AIzaSyDf9UUewy5p3ntG6cuHsofkE9E1g-4aTz4",
  "authDomain": "rviz-web.firebaseapp.com",
  "databaseURL": "https://rviz-web-default-rtdb.firebaseio.com",
  "projectId": "rviz-web",
  "storageBucket": "rviz-web.appspot.com",
  "messagingSenderId": "722402460534",
  "appId": "1:722402460534:web:bfccad25ed6bff4aaff057",
  "measurementId": "G-KCX4HMK6FJ",
  "serviceAccount": "/home/gokulbalaji/Rviz_web_project/fire/serviceAccount.json"
  
}




def delete(x):
    
    delete_temp_image_path = "frames/" + x
    storage.delete(delete_temp_image_path)

def delete_all():
    try:
        num=0
        while(1):
            delete(imageName(num))
            num= num+1
    except:
        print("deleted_all")

    
          
   
def upload(x):
    
    storage.child("frames/"+x).put(filePath + x)

def imageName(n):
    imageNameString=" "
    if(n>=0 and n<=9):
        imageNameString= "frame000"+ str(n)+ ".jpg"
    elif(n>=10 and n<=99):
        imageNameString= "frame00"+ str(n)+ ".jpg"
    elif(n>=100 and n<=999):
        imageNameString= "frame0"+ str(n)+ ".jpg"
    elif(n>=1000):
        imageNameString= "frame"+ str(n)+ ".jpg"
    return imageNameString





def start_uploading():
    x=0
    while(1):
              name= imageName(x)
              upload(name)
              print("uploaded frame "+name + "to firebase")
              x=x+1

    

firebase =pyrebase.initialize_app(config)
storage =firebase.storage()
delete_all()
start_uploading()


    



        
    
    
