def imageName(n):
    if(n>=0 and n<=9):
        print('yeah')
    